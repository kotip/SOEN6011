/**
 * 
 */

package sep;

import java.util.Scanner;

/**
 * @author kotic
 *Main function to get the values from the user and calculate by calling the methods.
 */

public class Finalmain {
  /**
   * Main function to get the values from the user and calculate by calling the methods.
   * 
   */
  public static void main(String[] args) {
    Finalfunction ff = new Finalfunction();
    double d;
    double id;
    double logvalue1;
    try {
      Scanner in = new Scanner(System.in);
      System.out.println("enter the value of x");
      id = in.nextDouble();
      System.out.println("enter the integer value of B");
      d = in.nextDouble();
      if (d > 1.0) {
        double logValue = ff.lognatural1(d);
        double xyz = id * logValue;
        double expValue = ff.exponential(xyz);
        System.out.println("calculated result is" + 2 * expValue);
      } 
      else if (d > 0.0) {
        logvalue1 = ff.lognatural(d);
        double res1 = id * logvalue1;
        double expvalue1 = ff.exponential(res1);
        System.out.println("calculated result is" + 2 * expvalue1);
      }
      else {
        System.out.println("error.Enter the values that are greater than Zero");
        
      }
    } catch (Exception e) {
      System.out.println("Exception Raised = " + e);
    }
  }
}
