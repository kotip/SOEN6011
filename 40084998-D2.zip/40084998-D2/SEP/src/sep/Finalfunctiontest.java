/**
 * 
 */

package sep;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

/**
 * @author kotic
 * This class tests all the methods 
 *
 */
public class Finalfunctiontest {
  Finalfunction ff = new Finalfunction();
  
  @Test
  public void lognaturalTest() {
    double d = 0.5;
    double res = ff.lognatural(d);
    assertEquals(-0.6931471805599445,res);
  }
  
  @Test
  public void lognatural1test() {
    double d = 12.00;
    double res = ff.lognatural1(d);
    assertEquals(2.48490664978799,res);
  }
  
  @Test
  public void exponentialTest() {
    double id = -2.77258872224;
    double res = ff.exponential(id);
    assertEquals(0.062499999999986525,res);
    
  }
  
  @Test
  public void exponentialTest1() {
    double id = 100;
    double res = ff.exponential(id);
    assertEquals(2.6881171418161336E43,res);
  }
}
