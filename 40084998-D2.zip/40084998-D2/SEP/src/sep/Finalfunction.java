/**
 * 
 */

package sep;

/**
 * @author kotic 
 * This class is used to calculate the value of ab^x function.
 *
 */
public class Finalfunction {

  /**
   * This function calculate the ln value which are in the range of 0 to 1.
   * 
   * @param d is passed that is given by the user
   * @return the result of ln value to calculate the exponential of that value
   */
  public double lognatural(double d) {
    double res = 0.0;
    double val1 = d - 1.0;
    double pow = -1.0;
    double denom = 2.0;
    double temp = val1;
    try {
      while (temp > 1E-15 || -temp > 1E-15) {
        if (temp > 1E-15) {
          res -= temp;
        } else {
          res += temp;
        }
        val1 = val1 * (d - 1.0);
        temp = val1 * pow;
        temp /= denom;
        pow *= -1.0;
        denom += 1.0;
      }
      res += temp;
    } catch (Exception e) {
      System.out.println("Exception Raised = " + e);
    }
    return res;
  }

  /**
   * This function calculate the ln value of values above 1.
   * 
   * @param d value is passed that is given by the user.
   * @return the result of ln value to calculate the exponential of that value
   */

  public double lognatural1(double d) {
    double res = 0.0;
    double val1 = (d - 1) / d;
    double denom = 2;
    double temp = val1;
    try {
      while (temp > 1E-15 || -temp > 1E-15) {
        res += temp;
        val1 *= (d - 1) / d;
        temp = val1 * (1.0 / denom);
        denom += 1;
      }
    } catch (Exception e) {
      System.out.println(" Exception Raised = " + e);
    }
    return res;
  }

  /**
   * This function calculate the exponential value.
   * 
   * @param id is passed that is given by the user.
   * @return result of exponential value.
   */
  public double exponential(double id) {
    double res = 1.0;
    double val1 = id;
    int denom = 2;
    try {
      while (val1 > 1E-16 || -val1 > 1E-16) {
        res += val1;
        val1 *= id;
        val1 /= denom;
        denom += 1;
      }
    } catch (Exception e) {
      System.out.println("Exception Raised = " + e);
    }
    return res;
  }
}

